﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameController : MonoBehaviour
{
    public static GameController instance;  // GameController 객체

    public Text[] buttonList;  // 9개 버튼의 텍스트가 연결된 배열
    private string playerMark = "X";  // O, X

    private void Awake()
    {
        // 싱글톤 패턴
        if (instance == null)
            instance = this;
        else if (instance != this)
            Destroy(this.gameObject);
    }

    // 현재 턴의 마크(O, X) 반환
    public string GetPlayerMark()
    {
        return playerMark;
    }

    #region 승리 조건 체크? GameOver() : ChangeMark()
    public void EndTurn()
    {
        #region 승리 조건 체크를 위한 2차원 가변 배열
        int[][] winConditionArray = new int[8][];
        winConditionArray[0] = new int[] { 0, 1, 2 };
        winConditionArray[1] = new int[] { 3, 4, 5 };
        winConditionArray[2] = new int[] { 6, 7, 8 };
        winConditionArray[3] = new int[] { 0, 3, 6 };
        winConditionArray[4] = new int[] { 1, 4, 7 };
        winConditionArray[5] = new int[] { 2, 5, 8 };
        winConditionArray[6] = new int[] { 0, 4, 8 };
        winConditionArray[7] = new int[] { 2, 4, 6 };
        #endregion

        // 승리 조건 체크
        for (int i = 0; i < winConditionArray.Length; i++)
        {
            if (CheckVictoryCondition(winConditionArray[i]))
            {
                print("누군가 승리함");
                GameOver(playerMark);  // 게임 종료 처리
                return;
            }
        }
        ChangeMark();  // player의 마크를 변경함.
    }

    private void ChangeMark()
    {
        playerMark = (playerMark == "X") ? "O" : "X";
    }

    private void GameOver(string winnerMark)
    {
        
    }

    public bool CheckVictoryCondition(int[] indexs)  // new int[] { 3, 4, 5 }
    {
        return buttonList[indexs[0]].text == playerMark &&
               buttonList[indexs[1]].text == playerMark &&
               buttonList[indexs[2]].text == playerMark;
    }
    #endregion

}
