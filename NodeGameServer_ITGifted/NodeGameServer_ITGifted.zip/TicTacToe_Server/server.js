var io = require('socket.io')({
	transports: ['websocket'],
});
io.attach(4567);
console.log("127.0.0.1:4567에서 서버 실행중...");

var ids = [];  // 플레이어들의 socket.id 저장
var userNames = [];  // 사용자 닉네임 저장

io.on('connection', function(socket){
  console.log("클라이언트 접속");
  ids.push(socket.id);  
  console.log('ids : ', ids, 'ids.length', ids.length);

	// 새로운 사용자 조인
	socket.on("join", function(data){  // data = {userName: "닉네임"}
    console.log("새로운 사용자 조인 : ", data.userName);
    userNames.push(data.userName);
    socket.userName = data.userName; 
    console.log('userNames : ', userNames);

    if(userNames.length == 1) // 접속자가 1명인 경우 기다리라는 메세지 전송.
      socket.emit("waitForAnotherUser");  
    else if(userNames.length == 2)  // 접속자가 2명이면 게임 시작 메세지 전송.
      io.emit("playGame");
	});
})