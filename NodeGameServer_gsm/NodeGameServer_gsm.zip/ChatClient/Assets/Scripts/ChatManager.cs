﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChatManager : MonoBehaviour
{
    [SerializeField] InputField chatBox;
    [SerializeField] GameObject chatPanel, textPrefab;
    private ChatNetwork chatNetwork;

    void Start()
    {
        chatNetwork = GetComponent<ChatNetwork>();
    }

    void Update()
    {
        // 만약 inputField에 새로운 텍스트가 있으면
        if(chatBox.text != "")
        {
            if (Input.GetKeyDown(KeyCode.Return))  // Enter키가 눌렸으면
            {
                //SendMsgToChat(chatBox.text);  // 입력된 텍스트를 화면에 출력
                chatNetwork.SendNewMsg(chatBox.text);  // 서버로 새로운 텍스트 송신
                chatBox.text = "";
                chatBox.ActivateInputField();  // 포커스가 입력창으로 오도록 한다.
            }
        }
        else
        {
            // 만약 입력차에 포커스가 없다면, Enter 키가 눌렸을 때 포커스가 입력창으로 가도록 설정
            if(!chatBox.isFocused && Input.GetKeyDown(KeyCode.Return))
            {
                chatBox.ActivateInputField();
            }
        }
        
    }

    // 채팅창에 새로운 텍스트 오브젝트 추가
    public void SendMsgToChat(string inputText)
    {
        GameObject newText = Instantiate(textPrefab, chatPanel.transform);  // textPrefab 클론 생성
        newText.GetComponent<Text>().text = inputText;  // inputField의 텍스트를 textPrefab에 작성
    }
}
