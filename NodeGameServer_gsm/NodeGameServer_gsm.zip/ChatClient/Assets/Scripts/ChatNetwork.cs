﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SocketIO;
using System;

public class ChatNetwork : MonoBehaviour
{
    private SocketIOComponent socket;
    private ChatManager chatManager;

    public void Start()
    {
        GameObject go = GameObject.Find("SocketIO");
        socket = go.GetComponent<SocketIOComponent>();
        chatManager = GetComponent<ChatManager>();

        socket.On("open", TestOpen);
        socket.On("boop", TestBoop);
        socket.On("error", TestError);
        socket.On("close", TestClose);

        socket.On("broadcastMsg", OnBroadcastMsg);
        //StartCoroutine(BeepBoop());  // 코루틴 함수 실행

    }

    #region 송신 이벤트 처리
    public void SendNewMsg(string msg)
    {
        Dictionary<string, string> data = new Dictionary<string, string>();
        data.Add("msg", msg);
        JSONObject jObject = new JSONObject(data);
        socket.Emit("newMsg", jObject);
    }
    #endregion

    private IEnumerator BeepBoop()
    {
        yield return new WaitForSeconds(1);  // wait 1 seconds and continue

        // 데이터를 서버로 전송하는 코드
        Dictionary<string, string> data = new Dictionary<string, string>();
        data.Add("msg", "Hello Server");
        JSONObject jObject = new JSONObject(data);
        socket.Emit("beep", jObject);  // 서버로 이벤트와 데이터 전송

    }

    #region 이벤트 리스너 함수
    private void OnBroadcastMsg(SocketIOEvent e)
    {
        chatManager.SendMsgToChat(e.data.GetField("msg").str);
    }


    public void TestOpen(SocketIOEvent e)
    {
        Debug.Log("[SocketIO] Open received: " + e.name + " " + e.data);
    }

    public void TestBoop(SocketIOEvent e)
    {
        Debug.Log("[SocketIO] Boop received: " + e.name + " " + e.data);  // {msg: "Hello Client!!!"}

        if (e.data == null) { return; }
        Debug.Log("데이터 추출 : " + e.data.GetField("msg").str);
    }

    public void TestError(SocketIOEvent e)
    {
        Debug.Log("[SocketIO] Error received: " + e.name + " " + e.data);
    }

    public void TestClose(SocketIOEvent e)
    {
        Debug.Log("[SocketIO] Close received: " + e.name + " " + e.data);
    }
    #endregion
}
